<?php ini_set('display_errors','on');

$servername = "localhost";
$username = "id2689058_ddb2";
$password = "distributedDB";
$database = "id2689058_ddb2";

?>
